

apt-get -y update
DEBIAN_FRONTEND=noninteractive apt-get -y upgrade


apt-get -y install bind9 bind9utils


cp -v /vagrant/files/venus/named.conf.{options,local} /etc/bind
cp -v /vagrant/files/tierra/named /etc/default/named

systemctl restart bind9