
apt-get -y update
DEBIAN_FRONTEND=noninteractive apt-get -y upgrade



apt-get -y install bind9 bind9utils


cp -v /vagrant/files/tierra/named /etc/default/named
cp -v /vagrant/files/tierra/named.conf.{options,local} /etc/bind
cp -v /vagrant/files/tierra/sistema.sol.dns /var/lib/bind
cp -v /vagrant/files/tierra/sol.192.168.57 /var/lib/bind
cp -v /vagrant/files/tierra/named /etc/default/
cp -v /vagrant/files/tierra/named.conf /etc/bind/
cp -v /vagrant/files/tierra/resolv.conf /etc/ 


systemctl restart bind9